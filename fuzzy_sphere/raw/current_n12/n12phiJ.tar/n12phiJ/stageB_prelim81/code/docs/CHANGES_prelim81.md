# stageB-v2.1-prelim81：用 81 态中途检查点做 N12 低 L 的初步 KK/OPE（2026-11-04）

## 目的

N12 半整数 L2 的正式窗口（5824）要等 183 态，预计 11-07 至 11-08 写盘。6194 已存下 81 态中途检查点（frontier 24.196，Δ 6.33；need 24.94，Δ 6.80）。这个变体用这份检查点作为 L2 的 KK target，先算出 N12 半整数扇区的 KK 投影和 L0–L1 的 OPE，作为**初步结果**。正式结果仍用 v2.0/v2.1 在 5824 之后算。

离线分析（`E:\CCFiles\fuzzy sphere\DQCP\phiphiJ_N12_prelim81_20261104`）已经说明 φφJ 与 L2 截断无关；这个作业给出 N12 的 KK 证书、L1 的 J′、J″ 等模式和全部 L0–L1 OPE 行。

## 改动（以 v2.1 `xy_half_lean.jl` d3ee0cd0… 为底，求解代码一行未改）

1. `XY_PRELIM_L2_PARTIAL=<检查点目录>`：
   - 把一份 v2.1 中途检查点当作最高原始 L（= `XY_MAX_KK_L+1`，N12 低 L 版是 L2）的窗口。这个 L 只当 KK target，不当 KK 源，也不当 OPE target。
   - 读入时核对 L、维数、g、basis_sha、raw_dmax 和 binding，并过 `window_gate`。
   - 只能与 `XY_STAGE=all`、空的 `XY_WINDOW_LS` 一起用，不求解窗口。
   - 输出目录里如果已经有这个 L 的正式窗口，就报错退出。
2. **KK 源截断**：
   - 每个 L 的源只保留 E < min over targets (frontier − atol) 的态，也就是冻结代码在第 635 行断言的条件。冻结代码遇到不满足的源会报错；这里改成去掉，并记进 `prelim_truncated_sources.csv`。
   - 窗口都完整时不会去掉任何源，结果就是 v2.1 的结果（回归 C 验证）。
3. **中途窗口的 PH 号**：检查点里没有 PH 号，`raw_spectrum` 中 L2 的 pseg 和 P 写 0。L2 不当源，所以 KK 和 OPE 都不用它的 PH 号。
4. `XY_PRELIM_COMPLEMENT=1`：所有输出写完后，对中途窗口做 v2.1 的补空间检验（同一函数，种子 99000+L），结果写到 `prelim_complement_L<L>.toml`。检验失败时退出码为 7，但已写出的结果保留。
5. **清单与版本**：
   - `stageB_manifest.toml` 的 status 写为 `preliminary_partial_top_window_truncated_KK_sources`，并加一节 `[prelim]`，记录检查点路径、sha、态数、frontier、去掉的源数和局限。
   - `LEAN_VERSION="stageB-v2.1-prelim81"`。
   - `EQUIVALENT_SCRIPTS` 加入 v2.1（d3ee0cd0…），这样 v2.0 的 L0/L1 窗口和 v2.1 的检查点都能通过 binding 核对。

## 局限（结果只能叫“初步”）

- L1 中 Δ ≳ 6.3 的 KK 源被去掉，对应的模式和 OPE 行没有。按 N8–11 的离线截断测试：
  - J 不变；
  - Δ≈3.18、4.5 的模式，矩阵元变化 ≤1e-4；
  - Δ 在 5.2–6.2 的模式，变化 1–20%（这些矩阵元本身约 1e-4）。
- L2 窗口没有 PH 分解；补空间检验在最后单独做。
- 方法与 N≤11 不同，不能进正式盲分析的同法序列。

## 回归门槛（`jobs/regress_N8_prelim81.sbatch`，N8，KK_L=1）

- A：用 v2.1 求 L0、L1，L2 停在 81 态检查点（另存一份），再续算完成并做 KK/OPE，`verify_stageB` 必须通过。
- C：用 prelim81 在 A 的完整窗口上跑，不读检查点。`lean_compare.jl` 与 A 比较必须 PASS，且不能去掉任何源。
- P：用 prelim81 在 A 的 L0/L1 加 81 态检查点上跑，并做补空间检验。`prelim_regress_check.py` 必须通过：
  - φ–J 控制量相同；
  - φφJ 的 |me| 相对差 ≤1e-10；
  - rank 0 的行相同；
  - L1 中 C₂=3、Δ<4.7 的模式 |me| 相对差 ≤1e-3；
  - L0 的投影目录相同；
  - 截断记录正确；
  - 补空间检验通过。
- 通过标记：`PRELIM81_REGRESS_N8_ALL_PASS`。

## N12 作业（`jobs/N12_prelim81_kkope.sbatch`）

- 节点：epyc9755-384-1，`--mem=360G`，128 线程，时限 4 天，`afterok` 依赖 N8 回归。
- 输入：
  - L0/L1 用 `Tcc_XY_Lean_20261028/stageB/half/N12/windows`（5821）的符号链接；
  - L2 用 `Tcc_XY_Lean_v21_20261102/stageB/half/N12_L2/windows/partial/L2_k081.ckpt`（6194）。
  - 两处都只读，5824 仍在往 v2.0 目录写 L2，不受影响。
- 输出：`Tcc_XY_Prelim81_20261104/stageB/half/N12_prelim81`。
- 内存估计：
  - KK 阶段约 240–260 GB：固定开销 67 GB，L1 窗口 78 GB，L2 检查点 91 GB，再加像缓冲；
  - 补空间检验约 180 GB。
- 时间：KK/OPE 约半天到 1.5 天，补空间检验再加几小时到 1 天，都不确定。
