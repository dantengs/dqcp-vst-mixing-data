# Stage B, lean variant (stageB-v2-lean, 2026-10-28).
# Same physics, thresholds, seeds and floating-point operations as xy_half_extend.jl (53d551,
# N5-N10 half/11) and xy_half_resume.jl (3729d7, N11 half KK to L3).  Only memory and job layout
# differ (docs/CHANGES_lean_v2.md):
#   * window solver: the prior window is the deflation basis in place (no copies), new columns are
#     written into the grown window, H/C2 post-processing in column chunks, in-place column sort;
#   * KK/OPE: source subsets are views, a window used as source and target is loaded once;
#   * XY_MAX_KK_L sets the KK/OPE spin range; raw windows go to XY_MAX_KK_L+1 (no L5 by default);
#   * XY_STAGE=windows + XY_WINDOW_LS solves only the listed raw windows, so several jobs can solve
#     different L into one output directory (one shared segment.ckpt); XY_STAGE=all reuses them;
#   * LEAN_MEM lines (VmRSS / VmHWM after a full GC) at every phase.
# v2.1 (2026-11-02, docs/CHANGES_v2.1.md) adds only checkpoint I/O around the unchanged solver:
#   * after every grown window that does not yet guard `need`, the window is saved to
#     windows/partial/L<L>_k<k>.ckpt (XY_PARTIAL_CKPT=0 disables); a restart resumes from the
#     largest saved k with the same next k and seed as the uninterrupted loop;
#   * XY_STOP_AFTER_K=k stops cleanly (LEAN_PARTIAL_STOP) once a partial window with >= k states
#     is saved;
#   * outputs of v2.0.0 (same inputs, solver-identical script) are accepted in place of v2.1 ones.
# prelim81 (2026-11-04, docs/CHANGES_prelim81.md) is a PRELIMINARY variant of v2.1 for KK/OPE only:
#   * XY_PRELIM_L2_PARTIAL=<partial ckpt> uses a saved partial window (windows/partial/L<L>_k<k>.ckpt
#     of v2.1) as the raw window of the top raw L (= XY_MAX_KK_L+1, a KK target only, never a KK
#     source or OPE target).  The partial is identity-checked (L, dim, g, basis, raw_dmax, binding)
#     and gated, but it carries no PH labels and no complement certificate;
#   * KK sources of every L are restricted to E < min over its targets of (frontier - atol), the
#     guard the frozen code asserts; with complete windows nothing is removed and the run is the v2.1
#     run.  Removed sources are listed in prelim_truncated_sources.csv;
#   * XY_PRELIM_COMPLEMENT=1 runs the v2.1 complement check on the partial window after all outputs
#     are written (prelim_complement_L<L>.toml).
# Without XY_PRELIM_L2_PARTIAL and with complete windows the outputs equal those of v2.1.
# julia xy_half_prelim81.jl RUN_TOML OUT_DIR OPE3_DIR [half|11] [max_nev=384]
# Source code remains frozen; accepted production files are read-only inputs.

const LEAN_VERSION="stageB-v2.1-prelim81"
# Scripts whose solver is identical to this one (only checkpoint I/O differs); their bindings and
# windows may be combined with prelim81 ones in one output directory.
const EQUIVALENT_SCRIPTS=Dict("e1ed38a00de814e914c8f3d3409bf750ce42c5d2a03ee161e1988573dc8ff954"=>"stageB-v2-lean",
    "d3ee0cd045e0d1b1c4187a30c8abdd3f0a099e1267b2c9c4aae752ab73dd8168"=>"stageB-v2.1-lean")
struct PartialStop <: Exception
    L::Int
    states::Int
    next_k::Int
end

"""Vnew[:, j] = V[:, o[j]] in place (one column buffer); same bytes as V[:, o]."""
function permute_cols!(V::AbstractMatrix{Float64},o::AbstractVector{Int})
    n=length(o);n==size(V,2) || error("permutation length")
    all(o[j]==j for j in 1:n) && return V
    done=falses(n);tmp=Vector{Float64}(undef,size(V,1))
    for i in 1:n
        if done[i] || o[i]==i
            done[i]=true;continue
        end
        copyto!(tmp,view(V,:,i));j=i
        while true
            done[j]=true;k=o[j]
            if k==i
                copyto!(view(V,:,j),tmp);break
            end
            copyto!(view(V,:,j),view(V,:,k));j=k
        end
    end
    V
end
parse_ls(s)=isempty(strip(s)) ? Int[] : sort(unique(parse.(Int,split(s,','))))
bits_equal(a,b)=size(a)==size(b) && all(i->reinterpret(UInt64,Float64(a[i]))==reinterpret(UInt64,Float64(b[i])),eachindex(a,b))

if !isempty(ARGS) && ARGS[1]=="--parse-only"
    Meta.parseall(read(@__FILE__,String));println("STAGEB_PARSE_PASS");exit(0)
end
if !isempty(ARGS) && ARGS[1]=="--self-test"
    using LinearAlgebra
    V=reshape(collect(1.0:42.0),6,7)
    for o in ([1,2,3,4,5,6,7],[7,6,5,4,3,2,1],[2,3,1,5,4,6,7],[3,1,2,7,4,5,6])
        W=copy(V);permute_cols!(W,o);@assert bits_equal(W,V[:,o])
    end
    @assert parse_ls("2,0,1,1")==[0,1,2] && parse_ls("")==Int[]
    v=Matrix{Float64}(I,3,3);q=[sqrt(.8),0.0,sqrt(.2)];op=[1.0 2.0 3.0]
    @assert abs(only(op*(v*q))-dot(vec(op),q))<1e-14
    @assert (1+(-1)*(-1))/2==1 && (1+1*(-1))/2==0
    idx=[2,4];sub=[1,2];globalids=idx[sub];Q=zeros(5,1);Q[globalids,1]=[.6,.8]
    @assert norm(Q)==1 && Q[2]==.6 && Q[4]==.8
    println("STAGEB_LEAN_HELPER_SELFTEST_PASS (in-place column permutation, L lists, full-Q, parity projector, index embedding)");exit(0)
end
include(get(ENV,"TCC_SOURCE_FILE","/nfs/work/sth/Tcc_v0.0.1_20261011/code_v027/v027/Tcc_v0.0.1/src/Tcc.jl"))
using .Tcc, LinearAlgebra, TOML, SHA, Printf, Random
required_api=[:_target_window,:_complement_check,:kk_classify,:edge_arrays,:kk_terms,:_ope3_edge,
    :segment_ph_maps,:comp_parity,:apply_parity,:parity_values,:window_gate,:column_shas,:ope3_spaces,
    :lowest,:lowest_deflated,:krylovdim,:polish_c2!,:post_h,:post_c,:NATIVE_DIM_MAX]
all(s->isdefined(Tcc,s),required_api) || error("Frozen Tcc API contract missing: $(filter(s->!isdefined(Tcc,s),required_api))")
if !isempty(ARGS) && ARGS[1]=="--api-check"
    println("STAGEB_FROZEN_API_PASS $(Tcc.TCC_VERSION) $LEAN_VERSION");exit(0)
end

# ---------------------------------------------------------------------------------------------
# Memory telemetry
function procmem()
    s=read("/proc/self/status",String)
    f(key)=(m=match(Regex("$key:\\s+(\\d+) kB"),s);m===nothing ? -1.0 : parse(Float64,m[1])*1024)
    (rss=f("VmRSS"),hwm=f("VmHWM"))
end
function memlog(tag)
    GC.gc();p=procmem()
    @printf("LEAN_MEM %s rss_gb=%.2f hwm_gb=%.2f live_gb=%.2f\n",tag,p.rss/1e9,p.hwm/1e9,Base.gc_live_bytes()/1e9);flush(stdout)
    p
end

# ---------------------------------------------------------------------------------------------
# Lean window solver.  Each function repeats the floating-point operations of the frozen Tcc
# function named in its docstring (same calls, same order, same seeds); only buffers differ.

"""Tcc.lowest without the final per-vector copies (Krylov path); dense path delegated."""
function lean_lowest(f,n::Int,k::Int,seed::Int;tol=1e-10,maxiter=500)
    k=min(k,n)
    n<=400 && return Tcc.lowest(f,n,k,seed;tol,maxiter)[1:2]
    alg=Tcc.KrylovKit.Lanczos(krylovdim=min(n,Tcc.krylovdim(k)),tol=tol,maxiter=maxiter,verbosity=0)
    E,V,info=Tcc.KrylovKit.eigsolve(f,normalize(randn(MersenneTwister(seed),n)),k,:SR,alg)
    o=sortperm(E)[1:min(k,length(E))]
    Float64.(E[o]),[V[i] isa Vector{Float64} ? V[i] : Vector{Float64}(V[i]) for i in o]
end

"""Tcc.lowest_deflated; the new eigenvectors are written into `dest` (n x k view), energies returned."""
function lean_deflated_into!(f,n::Int,k::Int,V0::AbstractMatrix{Float64},dest::AbstractMatrix{Float64},seed::Int;tol=1e-10,maxiter=500,Eref=nothing)
    m=size(V0,2);k=min(k,n-m)
    k<=0 && return Float64[]
    m==0 && error("lean_deflated_into! needs a non-empty deflation basis")
    scale=Eref===nothing ? 1.0 : maximum(abs,Eref;init=1.0)
    sigma=10*scale+100
    buf=zeros(m);pv=zeros(n)
    function g(v)
        mul!(buf,transpose(V0),v);mul!(pv,V0,buf)
        y=f(v-pv)
        mul!(buf,transpose(V0),y);mul!(y,V0,buf,-1.0,1.0)
        y.+=sigma.*pv
        y
    end
    E,V=lean_lowest(g,n,k,seed;tol,maxiter)
    GC.gc()
    r=length(V);W=Matrix{Float64}(undef,n,r)
    for j in 1:r
        v=V[j];W[:,j]=v-V0*(V0'*v);V[j]=Float64[]
    end
    V=nothing;GC.gc()
    Qw=Matrix(qr!(W).Q)                       # qr(W) of the frozen code = qr! on its copy
    size(Qw,2)==r || (Qw=Qw[:,1:r])
    W=nothing;GC.gc()
    FQ=Matrix{Float64}(undef,n,r)
    for j in 1:r; FQ[:,j]=f(Qw[:,j]); end
    Hs=Qw'*FQ
    FQ=nothing;GC.gc()
    F=eigen(Symmetric((Hs+Hs')/2))
    mul!(view(dest,:,1:r),Qw,F.vectors)
    maximum(abs.(F.values.-E))<1e-6*max(1,maximum(abs,E)) ||
        @warn "deflated Ritz values moved: $(maximum(abs.(F.values.-E)))"
    Float64.(F.values)
end

"""
Tcc._target_window(H, cp, 0, 0, k, seed, false, act, tol; prior) for one full block (no exchange
split).  `box[]` holds the prior window (energy, vectors) or nothing; it is consumed: the prior
columns are copied once into the grown window and the old matrix is released before Lanczos.
"""
function lean_target_window!(box::Ref{Any},H,D::Int,k::Int,seed::Int,act::Int,tol)
    f=v->*(H,v;num_th=act)
    pr=box[];box[]=nothing
    if pr===nothing || isempty(pr.energy)                 # frozen: empty prior -> plain lowest
        e,V=lean_lowest(f,D,k,seed+7;tol)
        GC.gc()
        o=sortperm(e);W=Matrix{Float64}(undef,D,length(e))
        for (j,i) in enumerate(o); copyto!(view(W,:,j),V[i]);V[i]=Float64[]; end
        return (energy=e[o],vectors=W)
    end
    m=length(pr.energy);size(pr.vectors)==(D,m) || error("prior window shape")
    a=max(0,min(k-m,D-m))
    Eref=copy(pr.energy)
    Vout=Matrix{Float64}(undef,D,m+a);copyto!(view(Vout,:,1:m),pr.vectors)
    pr=nothing;GC.gc()
    e=Float64[]
    if a>0
        e=lean_deflated_into!(f,D,a,view(Vout,:,1:m),view(Vout,:,m+1:m+a),seed+7+104729;tol,Eref)
        !isempty(e) && minimum(e)<maximum(Eref)-1e-8 &&
            error("target window sector 0: a deflated state lies below the prior window")
        length(e)<a && (Vout=Vout[:,1:m+length(e)];GC.gc())
    end
    E=vcat(Eref,e);o=sortperm(E)
    permute_cols!(Vout,o)
    (energy=E[o],vectors=Vout)
end

"""Tcc.polish_c2! with the C2 residual pass in column chunks (identical per-column arithmetic)."""
function lean_polish_c2!(E,V,parity,H,C;window=1e-3,trigger=1e-7,workers=Threads.nthreads(),chunk=8)
    isempty(E) && return 0
    _,rc=post_c(C,V;workers,chunk)
    done=falses(length(E));ngroups=0
    for i in sortperm(rc;rev=true)
        (rc[i]<=trigger || done[i]) && continue
        idx=[j for j in eachindex(E) if parity[j]==parity[i] && abs(E[j]-E[i])<window]
        length(idx)<2 && continue
        W=V[:,idx];CW=zeros(size(W));act_block!(CW,C,W;workers)
        F=eigen(Hermitian((W'*CW+CW'*W)/2));U=W*F.vectors
        groups=Vector{Int}[]
        for (k,c) in enumerate(F.values)
            isempty(groups) || abs(c-F.values[last(groups)[1]])>1e-6 ? push!(groups,[k]) : push!(last(groups),k)
        end
        newV=Vector{Float64}[];newE=Float64[]
        for gk in groups
            Ug=U[:,gk];HU=zeros(size(Ug));act_block!(HU,H,Ug;workers)
            G=eigen(Hermitian((Ug'*HU+HU'*Ug)/2));R=Ug*G.vectors
            append!(newE,G.values);append!(newV,[R[:,q] for q in axes(R,2)])
        end
        o=sortperm(newE);ix=sort(idx;by=j->E[j])
        for (q,j) in enumerate(ix); E[j]=newE[o[q]];V[:,j]=newV[o[q]]; end
        done[idx].=true;ngroups+=1
    end
    ngroups
end

"""Tcc._complement_check(H, cp, 0, 0, w, Dict(0=>D), false, act, tol, seed).min_margin with the
window matrix itself as deflation basis (the frozen code copies it into V0 first)."""
function lean_complement_check(H,D::Int,E::AbstractVector,V::Matrix{Float64},act::Int,tol,seed::Int;nextra::Int=2)
    m=length(E);m>=D && return (min_margin=Inf,)
    f=v->*(H,v;num_th=act)
    top=m==0 ? -Inf : maximum(E)
    Ec,_,_=lowest_deflated(f,D,nextra,V,seed;tol,Eref=E[1:m])
    (min_margin=isempty(Ec) ? Inf : minimum(Ec)-top,)
end

# ---------------------------------------------------------------------------------------------
function canonical_future(path)
    p=abspath(path);tail=String[]
    while !ispath(p)
        pushfirst!(tail,basename(p));q=dirname(p);q==p && error("Cannot resolve path parent");p=q
    end
    normpath(joinpath(realpath(p),tail...))
end
function contains_path(parent,child)
    p=Sys.iswindows() ? lowercase(parent) : parent;c=Sys.iswindows() ? lowercase(child) : child
    c==p || startswith(c,p*(Sys.iswindows() ? "\\" : "/"))
end

length(ARGS)>=3 || error("usage: RUN_TOML OUT_DIR OPE3_DIR [half|11] [max_nev]")
c=Tcc.pipeline_config(TOML.parsefile(ARGS[1])); c["g"]=Tcc.resolved_g(c)
N=Int(c["N"]); g=Float64(c["g"]); run=canonical_future(c["out"])
out=canonical_future(ARGS[2]); o3dir=canonical_future(ARGS[3]); sector=length(ARGS)>=4 ? ARGS[4] : "half"
sector in ("half","11") || error("sector must be half or 11")
any(p->contains_path(p,out)||contains_path(out,p),(run,o3dir)) && error("Stage B output must not overlap production/OPE directory trees")
cap=length(ARGS)>=5 ? parse(Int,ARGS[5]) : 384
raw_dmax=parse(Float64,get(ENV,"XY_KK_SOURCE_DMAX","6.8"))
raw_dmax>=6.6 || error("KK raw basis must reach at least Delta6.6")
haskey(ENV,"XY_MAX_KK_L") || error("XY_MAX_KK_L must be set explicitly (KK source and OPE spin range)")
kk_lmax=parse(Int,ENV["XY_MAX_KK_L"]);0<=kk_lmax<=4 || error("XY_MAX_KK_L must be 0..4");raw_lmax=kk_lmax+1
stage=get(ENV,"XY_STAGE","all");stage in ("probe","windows","all") || error("XY_STAGE must be probe, windows or all")
window_ls=parse_ls(get(ENV,"XY_WINDOW_LS",join(0:raw_lmax,",")))
all(L->0<=L<=raw_lmax,window_ls) || error("XY_WINDOW_LS outside 0:$raw_lmax")
postchunk=parse(Int,get(ENV,"XY_POST_CHUNK","8"));postchunk>=1 || error("XY_POST_CHUNK")
partial_ckpt=get(ENV,"XY_PARTIAL_CKPT","1")!="0"
stop_k=parse(Int,get(ENV,"XY_STOP_AFTER_K","0"));stop_k>=0 || error("XY_STOP_AFTER_K")
stop_k>0 && !partial_ckpt && error("XY_STOP_AFTER_K needs partial checkpoints (XY_PARTIAL_CKPT=1)")
stop_k>0 && stage!="windows" && error("XY_STOP_AFTER_K is only for XY_STAGE=windows")
prelim_partial=get(ENV,"XY_PRELIM_L2_PARTIAL","");prelim_L=raw_lmax
prelim_complement=get(ENV,"XY_PRELIM_COMPLEMENT","0")=="1"
if !isempty(prelim_partial)
    stage=="all" && isempty(window_ls) || error("XY_PRELIM_L2_PARTIAL needs XY_STAGE=all and an empty XY_WINDOW_LS (no window solving)")
    isdir(prelim_partial) || error("XY_PRELIM_L2_PARTIAL is not a checkpoint directory: $prelim_partial")
    prelim_partial=realpath(prelim_partial)
end
prelim_complement && isempty(prelim_partial) && error("XY_PRELIM_COMPLEMENT needs XY_PRELIM_L2_PARTIAL")
tol=1e-10; guard=1e-5; act=Threads.nthreads(); image_bytes=parse(Float64,get(ENV,"XY_IMAGE_BYTES","4e9"))
cache=joinpath(out,"operator_terms");mkpath(out)
memory_limit=parse(Float64,get(ENV,"XY_MEMORY_LIMIT_BYTES","280e9"))
memlog("start")
fit=Tcc._checked_load(joinpath(run,"kk","calibration.ckpt"))
report=TOML.parsefile(joinpath(o3dir,"ope3.toml"))
Int(report["N"])==N && abs(report["g"]-g)<1e-12 || error("OPE normalization is from another N/g")
abs(fit.alpha-report["alpha"])<1e-8 && abs(fit.E0-report["E0"])<1e-8 || error("Integer KK and OPE calibration differ")
cut=fit.E0+raw_dmax/fit.alpha; need=cut+max(1e-4,100guard)
Delta(E)=fit.alpha*(E-fit.E0)
lib=SegLibrary(builder=:tiled,tile_width=get(c,"tile",64),workers=get(c,"workers",act),opmat_threads=get(c,"native",8))

if sector=="half"
    oldseg=joinpath(o3dir,"half","segment.ckpt")
    basis_source=isdir(oldseg) ? String(Tcc._ckpt_sha(oldseg)) : "fresh_half_segment_N$N"
    make_seg=isdir(oldseg) ? (()->Tcc._checked_load(oldseg).space) : (()->build_half_segment(N))
    qn=[2N,0,2]
else
    spaces,bsha0=Tcc.ope3_spaces(c)
    seg11=spaces isa Tcc.SpaceStore ? Tcc.getspace!(spaces,1) : spaces[2]
    spaces=nothing
    basis_source=String(bsha0);qn=[2N,0,0]
    make_seg=()->seg11
end
# Job-specific settings (memory limit, L list, stage, chunk) are recorded in lean_jobs/, not in the
# binding, so that parallel window jobs and the final KK/OPE job share one binding.
binding=Dict("script_sha"=>Tcc.file_digest(@__FILE__),"config_sha"=>Tcc.file_digest(ARGS[1]),
    "calibration_sha"=>String(Tcc._ckpt_sha(joinpath(run,"kk","calibration.ckpt"))),
    "normalization_sha"=>Tcc.file_digest(joinpath(o3dir,"ope3.toml")),
    "source_tree_sha"=>Tcc.tree_digest(dirname(get(ENV,"TCC_SOURCE_FILE","/nfs/work/sth/Tcc_v0.0.1_20261011/code_v027/v027/Tcc_v0.0.1/src/Tcc.jl"))),
    "basis_source"=>basis_source,"N"=>N,"g"=>g,"sector"=>sector,"raw_dmax"=>raw_dmax,
    "max_nev"=>cap,"source_run"=>run,"ope3_source"=>o3dir,
    "projection_Lmax"=>kk_lmax,"raw_Lmax"=>raw_lmax,"variant"=>LEAN_VERSION)
"""A saved binding matches if it equals this one, or differs only in script_sha/variant and names a
solver-identical script (EQUIVALENT_SCRIPTS)."""
function binding_ok(saved)
    saved==binding && return true
    rest(d)=Dict(k=>v for (k,v) in d if !(k in ("script_sha","variant")))
    sh=get(saved,"script_sha","")
    haskey(EQUIVALENT_SCRIPTS,sh) && get(saved,"variant","")==EQUIVALENT_SCRIPTS[sh] && rest(saved)==rest(binding)
end
binding_path=joinpath(out,"input_binding.toml")
if isfile(binding_path)
    binding_ok(TOML.parsefile(binding_path)) || error("StageB frozen input binding changed; choose another isolated output directory")
else
    tmpb=binding_path*".tmp.$(getpid())";open(io->TOML.print(io,binding),tmpb,"w")
    try
        mv(tmpb,binding_path)
    catch
        rm(tmpb;force=true)
        binding_ok(TOML.parsefile(binding_path)) || error("StageB frozen input binding changed (concurrent job)")
    end
end
mkpath(joinpath(out,"lean_jobs"))
open(joinpath(out,"lean_jobs","$(stage)_L$(join(window_ls,'-'))_$(get(ENV,"SLURM_JOB_ID","nojob"))_$(getpid()).toml"),"w") do io
    TOML.print(io,Dict("stage"=>stage,"window_ls"=>window_ls,"memory_limit_bytes"=>memory_limit,"post_chunk"=>postchunk,
        "partial_ckpt"=>partial_ckpt,"stop_after_k"=>stop_k,
        "threads"=>act,"host"=>gethostname(),"slurm_job"=>get(ENV,"SLURM_JOB_ID",""),"variant"=>LEAN_VERSION))
end
segpath=joinpath(out,"segment.ckpt")
if !isdir(segpath)
    seg0=make_seg()
    try
        Tcc._atomic_save(segpath,(N=N,sector=sector,space=seg0,basis_source=basis_source))
    catch err
        isdir(segpath) || rethrow()          # a parallel job saved the shared segment first
    end
    seg0=nothing;GC.gc()
end
make_seg=nothing;seg11=nothing
savedseg=Tcc._checked_load(segpath)
savedseg.N==N && savedseg.sector==sector && savedseg.basis_source==basis_source || error("Output segment identity mismatch")
seg=savedseg.space;savedseg=nothing;GC.gc()          # every job computes with the saved copy
bsha=String(Tcc._ckpt_sha(segpath))
ss=[seg,seg]
memlog("segment")
maps,phmap_residual=segment_ph_maps(seg,N)
cs=Dict(L=>Tcc.BuildCompSpace(ss,qn,2L) for L in 0:raw_lmax)
if sector=="half" && haskey(Tcc.HALF_DIMS,N)
    (cs[0].dim,cs[1].dim)==Tcc.HALF_DIMS[N] || error("StageB half-sector dimension regression failed")
end
tpl=hamiltonian_template(N);sH,fH=segops_shared!(lib,ss,tpl.template);sC,fC=segops_shared!(lib,ss,tpl.c2)
memlog("setup")
@printf("LEAN_SETUP N=%d sector=%s seglib_gb=%.2f dims=%s kk_lmax=%d raw_lmax=%d stage=%s window_ls=%s threads=%d\n",
    N,sector,resident_bytes(lib)/1e9,string([cs[L].dim for L in 0:raw_lmax]),kk_lmax,raw_lmax,stage,string(window_ls),act);flush(stdout)
stage=="probe" && (println("LEAN_PROBE_DONE N=$N sector=$sector");exit(0))
windowpath(L)=joinpath(out,"windows","L$L.ckpt")
projectionpath(L)=joinpath(out,"kk","L$L.ckpt")
partialdir=joinpath(out,"windows","partial")
partialpath(L,k)=joinpath(partialdir,@sprintf("L%d_k%03d.ckpt",L,k))
function partial_ks(L)
    isdir(partialdir) || return Int[]
    ks=Int[]
    for f in readdir(partialdir)
        m=match(Regex("^L$(L)_k(\\d+)\\.ckpt\$"),f);m===nothing || push!(ks,parse(Int,m[1]))
    end
    sort(ks)
end
drop_partials(L;keep=0)=foreach(k->k==keep || rm(partialpath(L,k);recursive=true,force=true),partial_ks(L))

"""Save the window of a step that does not yet guard `need`: exactly the (energy, vectors) the loop
carries into the next step, plus the k and next k of the loop.  Older partials of L are removed
only after the new one is complete."""
function save_partial(L,E,V,k,next_k,frontier,c2,rh,rc)
    path=partialpath(L,k)
    ispath(path) && rm(path;recursive=true,force=true)       # stale copy of the same step from a crashed run
    Tcc._atomic_save(path,(energy=E,vectors=V,L=L,k=k,next_k=next_k,dim=size(V,1),g=g,basis_sha=bsha,
        raw_dmax=raw_dmax,frontier=frontier,required_energy=need,c2=c2,rh=rh,rc=rc,
        input_binding=binding,code=Tcc.producer_info()))
    drop_partials(L;keep=k)
    memlog("partial_L$(L)_k$k")
    println("STAGEB_PARTIAL_SAVED L=$L states=$(length(E)) k=$k next_k=$next_k path=$path");flush(stdout)
end

"""Largest saved partial window of L, identity-checked, or nothing."""
function load_partial(L)
    ks=partial_ks(L);isempty(ks) && return nothing
    path=partialpath(L,last(ks));p=Tcc._checked_load(path)
    p.L==L && p.dim==cs[L].dim && p.g==g && p.basis_sha==bsha && p.raw_dmax==raw_dmax && binding_ok(p.input_binding) &&
        size(p.vectors)==(p.dim,length(p.energy)) && issorted(p.energy) && p.next_k>p.k ||
        error("Partial StageB window identity mismatch: $path")
    println("STAGEB_PARTIAL_RESUME L=$L states=$(length(p.energy)) k=$(p.k) next_k=$(p.next_k) frontier=$(p.frontier) path=$path");flush(stdout)
    p
end

"""Refuse a solve step before allocating when the lean peak would exceed the limit.  Peak columns
of D: max(copy of the prior into the grown window, grown window + Krylov basis + Ritz vectors)."""
function lean_guard(L,m,kadd)
    D=cs[L].dim;a=max(0,min(kadd,D-m));kd=min(D,Tcc.krylovdim(max(a,1)))
    cols=max(2m+a,(m+a)+kd+2a+6)
    base=max(0.0,memlog("guard_L$(L)_m$(m)").rss-8.0*D*m)
    estimate=base+8.0*D*cols
    @printf("STAGEB_MEMORY_GUARD L=%d m=%d add=%d krylov=%d peak_columns=%d base_gb=%.2f estimate_gb=%.2f limit_gb=%.2f\n",
        L,m,a,kd,cols,base/1e9,estimate/1e9,memory_limit/1e9);flush(stdout)
    estimate<=memory_limit || error("STAGEB_MEMORY_BOUND L$L m=$m add=$a requires estimated $(estimate/1e9) GB; no unsafe allocation attempted")
end

function ph_resolve!(E,V,C2,plan)
    k=length(E);pm=zeros(k,k)
    for j in 1:k
        pv=apply_parity(plan,Matrix(V[:,j:j]));pm[:,j]=V'*view(pv,:,1)
    end
    done=falses(k)
    for i in 1:k
        done[i] && continue
        ids=[j for j in i:k if !done[j] && abs(E[j]-E[i])<=1e-7 && abs(C2[j]-C2[i])<1e-5]
        if length(ids)>1
            u=eigen(Hermitian((pm[ids,ids]+pm[ids,ids]')/2)).vectors;V[:,ids]=V[:,ids]*u
        end
        done[ids].=true
    end
    p=zeros(Int,k);res=0.0
    for j in 1:k
        vals,rs=parity_values(plan,Matrix(V[:,j:j]));res=max(res,only(rs));p[j]=round(Int,only(vals))
        abs(abs(only(vals))-1)<=1e-6 && only(rs)<=1e-6 || error("Raw state not a pure PH eigenstate")
    end
    p,res
end

"""Prior window as in the frozen code, without copying the loaded vectors."""
function prior_window(L,H,C)
    w=nothing
    if sector=="half"
        path=joinpath(o3dir,"half","blocks","L$L","eig.ckpt")
        if isdir(path)
            old=Tcc._checked_load(path)
            old.g==g && old.segment_sha==basis_source && old.dim==cs[L].dim || error("Existing half-window identity mismatch")
            w=(energy=old.energy,vectors=old.vectors);old=nothing
        end
    else
        a=source_window(run,1,1,L);b=target_window(run,1,1,L)
        w0=a===nothing ? b : b===nothing || length(a.E)>=length(b.E) ? a : b
        a=nothing;b=nothing
        if w0!==nothing
            w0.basis_sha==basis_source && w0.dim==cs[L].dim || error("Existing integer-window identity mismatch")
            w=(energy=w0.E,vectors=w0.V)
        end
        w0=nothing
    end
    w===nothing && return nothing
    rh=post_h(H,w.vectors,w.energy;workers=act,chunk=postchunk);cc,rc=post_c(C,w.vectors;workers=act,chunk=postchunk)
    try
        window_gate("StageB prior L$L",w.energy,w.vectors;rh,rc,c2=cc)
        ck=lean_complement_check(H,cs[L].dim,w.energy,w.vectors,act,tol,77100+L)
        ck.min_margin>guard || return nothing
        return w
    catch err
        println("STAGEB_PRIOR_NOT_REUSED L=$L reason=$(sprint(showerror,err))");flush(stdout)
        return nothing
    end
end

"""Grow, gate, PH-resolve and save the raw window of L (control flow of the frozen loop body)."""
function solve_window(L)
    path=windowpath(L);D=cs[L].dim
    H=absorb!(set_g!(Tcc.BuildCompOperator(cs[L],tpl.template,sH;num_th=act),tpl,g),fH)
    C=absorb!(Tcc.BuildCompOperator(cs[L],tpl.c2,sC;num_th=act),fC)
    pw=partial_ckpt ? load_partial(L) : nothing
    if pw===nothing
        box=Ref{Any}(prior_window(L,H,C))
        k=min(D,cap,max(24,box[]===nothing ? 0 : length(box[].energy)))
    else                                      # the state of the loop after step pw.k, as saved
        box=Ref{Any}((energy=pw.energy,vectors=pw.vectors));k=pw.next_k;pw=nothing
    end
    memlog("prior_L$L")
    while true
        retry_fresh=false
        m=box[]===nothing ? 0 : length(box[].energy)
        if m>=k
            E=box[].energy;V=box[].vectors
        else
            lean_guard(L,m,k-m)
            w=lean_target_window!(box,H,D,k,88000+100L+k,act,tol)
            E=w.energy;V=w.vectors;w=nothing
        end
        box[]=nothing
        memlog("solved_L$(L)_k$k")
        zeroP=zeros(Int,length(E))
        resolve_c2!(E,V,zeroP,C;tol=1e-6,workers=act);lean_polish_c2!(E,V,zeroP,H,C;workers=act,chunk=postchunk)
        order=sortperm(E);E=E[order];permute_cols!(V,order)
        rh=post_h(H,V,E;workers=act,chunk=postchunk);cc,rc=post_c(C,V;workers=act,chunk=postchunk)
        window_gate("StageB half/raw L$L",E,V;rh,rc,c2=cc)
        frontier=window_frontier(E,zeros(Int,length(E)),Dict(0=>D);guard)
        println("STAGEB_WINDOW N=$N sector=$sector L=$L dim=$D states=$(length(E)) DeltaTop=$(Delta(last(E))) frontier=$frontier need=$need");flush(stdout)
        if frontier>need
            chk=lean_complement_check(H,D,E,V,act,tol,99000+L)
            if chk.min_margin>guard
                plan=comp_parity(cs[L],maps,maps);pseg,pres=ph_resolve!(E,V,cc,plan)
                rh=post_h(H,V,E;workers=act,chunk=postchunk);cc,rc=post_c(C,V;workers=act,chunk=postchunk)
                gate=window_gate("StageB parity-resolved L$L",E,V;rh,rc,c2=cc)
                # PH diagonalization rotates within the same retained span;
                # the complement-prefix certificate is invariant under this unitary.
                frontier=window_frontier(E,zeros(Int,length(E)),Dict(0=>D);guard)
                frontier>need || error("Post-PH window frontier no longer guards requested basis")
                payload=(energy=E,vectors=V,c2=cc,rh=rh,rc=rc,dim=D,g=g,basis_sha=bsha,
                    qn=qn,sector=sector,N=N,raw_dmax=raw_dmax,frontier=frontier,required_energy=need,
                    pseg=pseg,parity_residual=pres,independent_min_margin=chk.min_margin,
                    colsha=column_shas(V),gate=gate,calibration=fit,input_binding=binding,code=Tcc.producer_info())
                Tcc._atomic_save(path,payload)
                memlog("saved_L$L")
                drop_partials(L)
                return nothing
            else
                println("STAGEB_EXTEND_TERMINAL_CLUSTER L=$L margin=$(chk.min_margin)");flush(stdout)
                retry_fresh=true
            end
        end
        k>=min(cap,D) && error("INCOMPLETE_STAGEB_WINDOW L$L cap=$cap reached")
        next_k=min(cap,D,max(k+8,ceil(Int,1.5k)))
        if partial_ckpt
            retry_fresh ? drop_partials(L) : save_partial(L,E,V,k,next_k,frontier,cc,rh,rc)
        end
        nstates=length(E)
        box[]=retry_fresh ? nothing : (energy=E,vectors=V)
        E=nothing;V=nothing;cc=nothing;rh=nothing;rc=nothing
        k=next_k
        stop_k>0 && !retry_fresh && nstates>=stop_k && throw(PartialStop(L,nstates,k))
    end
end

# Bitwise A/B of every lean solver function against the frozen one on block L (regression jobs).
if haskey(ENV,"XY_LEAN_SELFTEST_L")
    L=parse(Int,ENV["XY_LEAN_SELFTEST_L"]);k=parse(Int,get(ENV,"XY_LEAN_SELFTEST_K","24"))
    get(ENV,"XY_FORCE_BLOCK_KERNEL","0")=="1" && (Tcc.NATIVE_DIM_MAX[]=0)
    D=cs[L].dim;fails=String[]
    chk(name,ok)=(println("LEAN_SELFTEST $name ",ok ? "identical" : "DIFFERENT");ok || push!(fails,name))
    H=absorb!(set_g!(Tcc.BuildCompOperator(cs[L],tpl.template,sH;num_th=act),tpl,g),fH)
    C=absorb!(Tcc.BuildCompOperator(cs[L],tpl.c2,sC;num_th=act),fC)
    seed=88000+100L+k
    ref=Tcc._target_window(H,cs[L],0,0,k,seed,false,act,tol)
    lean1=lean_target_window!(Ref{Any}(nothing),H,D,k,seed,act,tol)
    chk("fresh_energy",bits_equal(ref.energy,lean1.energy));chk("fresh_vectors",bits_equal(ref.vectors,lean1.vectors))
    m=k÷2;k2=k+max(8,k÷2)
    pr=(energy=ref.energy[1:m],vectors=ref.vectors[:,1:m],parity=zeros(Int,m))
    ref2=Tcc._target_window(H,cs[L],0,0,k2,seed+1,false,act,tol;prior=pr)
    lean2=lean_target_window!(Ref{Any}((energy=copy(pr.energy),vectors=copy(pr.vectors))),H,D,k2,seed+1,act,tol)
    chk("deflated_energy",bits_equal(ref2.energy,lean2.energy));chk("deflated_vectors",bits_equal(ref2.vectors,lean2.vectors))
    E=ref2.energy;V=ref2.vectors
    chk("post_h_chunk",bits_equal(post_h(H,V,E;workers=act),post_h(H,V,E;workers=act,chunk=3)))
    a1,b1=post_c(C,V;workers=act);a2,b2=post_c(C,V;workers=act,chunk=3)
    chk("post_c_chunk",bits_equal(a1,a2) && bits_equal(b1,b2))
    z=zeros(Int,length(E));E1=copy(E);V1=copy(V);E2=copy(E);V2=copy(V)
    n1=Tcc.polish_c2!(E1,V1,z,H,C;workers=act);n2=lean_polish_c2!(E2,V2,z,H,C;workers=act,chunk=3)
    chk("polish(groups=$n1)",n1==n2 && bits_equal(E1,E2) && bits_equal(V1,V2))
    c1=Tcc._complement_check(H,cs[L],0,0,(energy=E,vectors=V,parity=zeros(Int,length(E))),Dict(0=>D),false,act,tol,99000+L)
    c2=lean_complement_check(H,D,E,V,act,tol,99000+L)
    chk("complement_margin",bits_equal([c1.min_margin],[c2.min_margin]))
    o=vcat(collect(length(E):-1:1));V3=copy(V);permute_cols!(V3,o);chk("permute_cols",bits_equal(V3,V[:,o]))
    isempty(fails) || error("LEAN_SELFTEST_FAIL L=$L block_kernel=$(Tcc.NATIVE_DIM_MAX[]==0): $(join(fails,", "))")
    println("LEAN_SELFTEST_PASS N=$N L=$L k=$k dim=$D block_kernel=$(Tcc.NATIVE_DIM_MAX[]==0)");exit(0)
end

# ---------------------------------------------------------------------------------------------
# prelim81: window metadata, partial top-L window, uniform window access
wmeta=Dict{Int,Any}()          # L => (energy, c2, frontier, maxrh, sha, partial)
"""The partial window named by XY_PRELIM_L2_PARTIAL, identity-checked like load_partial."""
function load_prelim_partial()
    p=Tcc._checked_load(prelim_partial);L=prelim_L
    p.L==L && p.dim==cs[L].dim && p.g==g && p.basis_sha==bsha && p.raw_dmax==raw_dmax && binding_ok(p.input_binding) &&
        size(p.vectors)==(p.dim,length(p.energy)) && issorted(p.energy) && length(p.c2)==length(p.energy) ||
        error("PRELIM partial window identity mismatch: $prelim_partial")
    p
end
usepartial(L)=!isempty(prelim_partial) && L==prelim_L
load_window(L)=usepartial(L) ? load_prelim_partial() : Tcc._checked_load(windowpath(L))
window_sha(L)=usepartial(L) ? String(Tcc._ckpt_sha(prelim_partial)) : String(Tcc._ckpt_sha(windowpath(L)))

stopped=Ref{Union{Nothing,PartialStop}}(nothing)
for L in 0:raw_lmax
    stage=="windows" && !(L in window_ls) && continue      # another job owns this L
    path=windowpath(L)
    if usepartial(L)
        ispath(path) && error("PRELIM: a window L$L exists in $out; a partial window may not replace it")
        p=load_prelim_partial()
        window_gate("PRELIM partial L$L",p.energy,p.vectors;rh=p.rh,rc=p.rc,c2=p.c2)
        wmeta[L]=(energy=copy(p.energy),c2=copy(p.c2),frontier=p.frontier,maxrh=maximum(p.rh),sha=window_sha(L),partial=true,k=p.k)
        println("PRELIM_PARTIAL_WINDOW N=$N sector=$sector L=$L states=$(length(p.energy)) k=$(p.k) frontier=$(p.frontier) ",
            "frontier_Delta=$(Delta(p.frontier)) DeltaTop=$(Delta(last(p.energy))) need=$need sha=$(wmeta[L].sha) path=$prelim_partial");flush(stdout)
        p=nothing;GC.gc();continue
    end
    if isdir(path)
        w=Tcc._checked_load(path)
        w.g==g && w.basis_sha==bsha && w.raw_dmax==raw_dmax && w.frontier>need && binding_ok(w.input_binding) || error("Cached StageB window identity/frontier mismatch")
        window_gate("StageB saved L$L",w.energy,w.vectors;rh=w.rh,rc=w.rc,c2=w.c2)
        wmeta[L]=(energy=copy(w.energy),c2=copy(w.c2),frontier=w.frontier,maxrh=maximum(w.rh),sha=window_sha(L),partial=false,k=length(w.energy))
        println("STAGEB_WINDOW_REUSE N=$N sector=$sector L=$L states=$(length(w.energy))");flush(stdout)
        w=nothing;GC.gc();continue
    end
    L in window_ls || error("LEAN_MISSING_WINDOW L$L is neither in XY_WINDOW_LS nor saved in $out")
    lockdir=joinpath(out,"windows",".solving_L$L");mkpath(dirname(lockdir))
    try
        mkdir(lockdir)
    catch
        error("Another job is solving L$L ($lockdir exists; remove it only if that job is dead)")
    end
    try
        solve_window(L)
    catch err
        err isa PartialStop || rethrow()
        stopped[]=err
    finally
        rm(lockdir;force=true,recursive=true)
    end
    GC.gc()
    stopped[]===nothing || break
end
if stopped[]!==nothing
    s=stopped[]
    println("LEAN_PARTIAL_STOP N=$N sector=$sector L=$(s.L) states=$(s.states) next_k=$(s.next_k) stop_after_k=$stop_k");flush(stdout)
    exit(0)
end
memlog("windows_done")
if stage=="windows"
    println("LEAN_WINDOWS_DONE N=$N sector=$sector L=$(window_ls)");flush(stdout);exit(0)
end
for L in 0:raw_lmax                                         # windows solved by this run
    haskey(wmeta,L) && continue
    w=Tcc._checked_load(windowpath(L))
    wmeta[L]=(energy=copy(w.energy),c2=copy(w.c2),frontier=w.frontier,maxrh=maximum(w.rh),sha=window_sha(L),partial=false,k=length(w.energy))
    w=nothing;GC.gc()
end

# Calibrate only the overall PH-sector sign against a known raw multiplet;
# the lowering-generator coefficients remain exactly the integer-run fit.
w0=Tcc._checked_load(windowpath(0));anchor_c2=sector=="half" ? 2 : 5;anchor_P=sector=="half" ? -1 : 1
ix=findall(x->abs(x-anchor_c2)<1e-5,w0.c2);isempty(ix) && error("Missing parity anchor")
j=ix[argmin(w0.energy[ix])];integer0=source_window(run,0,0,0)
ii=findall(x->abs(x-anchor_c2)<1e-5,integer0.C2);isempty(ii) && error("Missing integer parity anchor")
abs(w0.energy[j]-minimum(integer0.E[ii]))<=1e-6 || error("Half/integer parity-anchor energy mismatch")
vacfactor=anchor_P*w0.pseg[j];integer0=nothing;w0=nothing;GC.gc()
raw_catalog_rows=Any[]
for L in 0:raw_lmax
    if usepartial(L)                                        # no PH labels in a partial: pseg = P = 0
        m=wmeta[L]
        for i in eachindex(m.energy)
            push!(raw_catalog_rows,(N,sector,L,i,m.energy[i],Delta(m.energy[i]),m.c2[i],0,m.sha))
        end
        continue
    end
    w=Tcc._checked_load(windowpath(L));wsha=String(Tcc._ckpt_sha(windowpath(L)))
    for i in eachindex(w.energy)
        push!(raw_catalog_rows,(N,sector,L,i,w.energy[i],Delta(w.energy[i]),w.c2[i],w.pseg[i],wsha))
    end
    w=nothing;GC.gc()
end
Tcc._csv(joinpath(out,"raw_spectrum_Lle$(raw_lmax).csv"),["N","sector","L","raw_index","energy","Delta","C2","pseg","window_sha","P"],
    [(r...,r[8]*vacfactor*(-1)^r[3]) for r in raw_catalog_rows])
if sector=="half"
    pick(E,C,cc)=(ii=findall(x->abs(x-cc)<1e-5,C);isempty(ii) && error("Missing control irrep");ii[argmin(E[ii])])
    n0=Tcc._checked_load(windowpath(0));np=pick(n0.energy,n0.c2,2)
    s=(V=n0.vectors[:,np:np],sha=String(Tcc._ckpt_sha(windowpath(0)))*"|phi$np");phiE=n0.energy[np];n0=nothing;GC.gc()
    n1=Tcc._checked_load(windowpath(1));nj=pick(n1.energy,n1.c2,3)
    current_P=n1.pseg[nj]*vacfactor*(-1)
    current_Delta=Delta(n1.energy[nj])
    current_P==1 && abs(current_Delta-2.0)<1e-6 || error("StageB current parity/Ward energy-scale anchor failed")
    t=(V=n1.vectors[:,nj:nj],sha=String(Tcc._ckpt_sha(windowpath(1)))*"|J$nj");curE=n1.energy[nj];n1=nothing;GC.gc()
    o0=Tcc._checked_load(joinpath(o3dir,"half","blocks","L0","eig.ckpt"));op=pick(o0.energy,o0.c2,2);o0=nothing
    o1=Tcc._checked_load(joinpath(o3dir,"half","blocks","L1","eig.ckpt"));oj=pick(o1.energy,o1.c2,3);o1E=o1.energy;o1=nothing;GC.gc()
    oldedge=Tcc._checked_load(joinpath(o3dir,"half","edges","half_gamma2_r1_phi_L1.ckpt"))
    oldedge.scols==[op] && size(oldedge.overlaps[1],1)==length(o1E) || error("Old current-control edge/window identity mismatch")
    abs(curE-o1E[oj])<1e-6 || error("Current-control energy changed")
    id=(tag="StageB_independent_raw_phi_J_regression",source=s.sha,target=t.sha,g=g,input_binding=binding,
        reference_sha=String(Tcc._ckpt_sha(joinpath(o3dir,"half","edges","half_gamma2_r1_phi_L1.ckpt"))))
    edge=Tcc._ope3_edge(out,"raw_phi_J_control",lib,ss,cs[0],cs[1],ope3_terms(N,:gamma2,1;cache),2,s,[1],t,id;workers=act,image_bytes)
    oldabs=abs(oldedge.overlaps[1][oj,1]);newabs=abs(edge.overlaps[1][1,1]);bound=1e-7*max(1,oldabs)
    abs(newabs-oldabs)<=bound || error("STAGEB_RAW_CURRENT_REGRESSION_FAILED old=$oldabs new=$newabs")
    open(joinpath(out,"raw_current_control.toml"),"w") do io
        TOML.print(io,Dict("status"=>"pass","old_abs_ME"=>oldabs,"new_abs_ME"=>newabs,
            "absolute_difference"=>abs(newabs-oldabs),"tolerance"=>bound,"current_P"=>current_P,"current_Delta"=>current_Delta,
            "old_edge_sha"=>id.reference_sha,"new_phi_energy"=>phiE,"new_current_energy"=>curE))
    end
    println("STAGEB_RAW_CURRENT_REGRESSION_PASS N=$N diff=$(abs(newabs-oldabs))");flush(stdout)
    s=nothing;t=nothing;oldedge=nothing;edge=nothing;GC.gc()
end
memlog("controls_done")

truncated_rows=Any[]
function kk_stage()
    reps=Set([0,2,3,5,6,8,9,10,14]);kt=kk_terms(N;cache)
    catalog=Any[];coverage=Any[]
    for li in 0:kk_lmax
        w=Tcc._checked_load(windowpath(li))
        # prelim81: keep only sources the frozen guard below accepts for every target window
        tls=li==0 ? [1] : [li-1,li,li+1]
        lim=minimum(wmeta[lf].frontier-max(1e-8,10*(maximum(w.rh)+wmeta[lf].maxrh)) for lf in tls)
        cand=[i for i in eachindex(w.energy) if w.energy[i]<=cut && round(Int,w.c2[i]) in reps]
        ids=[i for i in cand if w.energy[i]<lim]
        for i in setdiff(cand,ids)
            push!(truncated_rows,(N,sector,li,i,w.energy[i],Delta(w.energy[i]),w.c2[i],w.pseg[i],lim,Delta(lim),
                join([lf for lf in tls if !(w.energy[i]<wmeta[lf].frontier-max(1e-8,10*(maximum(w.rh)+wmeta[lf].maxrh)))],";")))
        end
        length(ids)<length(cand) && (println("PRELIM_KK_SOURCES_TRUNCATED N=$N L=$li kept=$(length(ids)) removed=$(length(cand)-length(ids)) limit_E=$lim limit_Delta=$(Delta(lim))");flush(stdout))
        isempty(ids) && error("No StageB raw KK sources L$li")
        S=(E=w.energy[ids],V=view(w.vectors,:,ids),C2=w.c2[ids],parity=zeros(Int,length(ids)))
        source_sha=String(Tcc._ckpt_sha(windowpath(li)));edges=Any[]
        for lf in tls
            t=lf==li ? w : load_window(lf);atol=max(1e-8,10*(maximum(w.rh)+maximum(t.rh)))
            maximum(S.E)<t.frontier-atol || error("StageB KK target frontier insufficient")
            memlog("kk_L$(li)_L$(lf)")
            A=edge_arrays(lib,ss,cs[li],cs[lf],kt,2,S.V,t.vectors;workers=act,chunk=1)
            mask=[abs(a-b)>1e-5 for a in t.c2,b in S.C2]
            all(norm(M.*mask)<=1e-6*max(1,norm(M)) for M in A.overlaps) || error("StageB generator changes C2")
            edge=(li=li,lf=lf,source_E=S.E,source_C2=S.C2,target_E=t.energy,target_C2=t.c2,
                overlaps=A.overlaps,image_gram=A.image_gram,energy_atol=atol,target_frontier=t.frontier,
                target_parities=[0],source_sha=source_sha,target_sha=window_sha(lf),input_binding=binding)
            Tcc._atomic_save(joinpath(out,"kk","edges","L$(li)_L$(lf).ckpt"),edge);push!(edges,edge)
            println("STAGEB_KK_EDGE N=$N sector=$sector L$li->$lf");flush(stdout);t=nothing;A=nothing;GC.gc()
        end
        modes=Any[]
        for ps in (-1,1)
            loc=findall(==(ps),w.pseg[ids]);isempty(loc) && continue
            sub=(E=S.E[loc],C2=S.C2[loc],parity=zeros(Int,length(loc)))
            es=[merge(e,(overlaps=[M[:,loc] for M in e.overlaps],image_gram=e.image_gram[:,:,loc])) for e in edges]
            chans=Tcc.kk_classify(es,sub,li,fit.coefficients;threshold=.25)
            for ch in chans
                push!(coverage,(sector,li,ch.C2,ps,ch.status,length(ch.source_ids),length(ch.excluded_ids),join(ch.missing_L,";")))
                ch.Q===nothing && continue
                globalids=ids[loc[ch.source_ids]]
                for k in axes(ch.Q,2)
                    q=zeros(length(w.energy));q[globalids]=ch.Q[:,k]
                    pphys=ps*vacfactor*(-1)^li
                    label="$(sector)_KK_C2_$(ch.C2)_P$(pphys)_m$(k)"
                    mode=(label=label,c2=ch.C2,P=pphys,pseg=ps,energy=ch.energies[k],
                        sigmaE=ch.energy_mixing_residual[k],K2=dot(ch.Q[:,k],ch.K2*ch.Q[:,k]),coeff=q,
                        source_sha=source_sha,coverage=ch.status)
                    push!(modes,mode);push!(catalog,(N,sector,li,label,ch.C2,pphys,Delta(mode.energy),mode.sigmaE,mode.K2,source_sha,ch.status))
                end
            end
        end
        Tcc._atomic_save(projectionpath(li),(N=N,L=li,sector=sector,modes=modes,source_sha=source_sha,
            calibration=fit,raw_dmax=raw_dmax,threshold=.25,vacuum_raw_factor=vacfactor,input_binding=binding))
        w=nothing;S=nothing;edges=nothing;GC.gc()
    end
    catalog,coverage
end
catalog,coverage=kk_stage()
memlog("kk_done")

function tensor_parts(N,l)
    n=Tcc.GetDensityObs(N,2,Matrix{Float64}(I,2,2);norm_r2=1.0)
    pair=Tcc.StoreComps(Tcc.GetPairingObs(N,2,[0.0 1;0 0];norm_r2=1.0,mom_incr=false))
    d=Tcc.StoreComps(Tcc.SphereObs(pair.s2,pair.l2m,(l2,m2)->(-1)^(m2÷2)*pair.get_comp(l2,-m2)))
    nn=Tcc.FuzzifiED.SO3lver.AngModes(Tcc.StoreComps(n*n));one=Tcc.FuzzifiED.SO3lver.AngModes(Tcc.StoreComps(n));q=[0,0,0]
    aa=Tcc.SingleSegCouple(2,1,nn,2l,q);bb=Tcc.SingleSegCouple(2,2,nn,2l,q)
    ab=Tcc.ContactCouple([n,n],zeros(Int,3,2),2l)/sqrt(4pi)
    na=Tcc.SingleSegCouple(2,1,one,2l,q);nb=Tcc.SingleSegCouple(2,2,one,2l,q)
    pp=(Tcc.ContactCouple([d',d],[2 -2;0 0;0 0],2l)+Tcc.ContactCouple([d,d'],[-2 2;0 0;0 0],2l))/sqrt(4pi)
    pref=4/(sqrt(20)*N^2)
    [pref*(aa+bb-ab-N/(4pi)*(na+nb)),pref*(-2pp)]
end
function projected(L,dmax)
    w=Tcc._checked_load(windowpath(L));p=Tcc._checked_load(projectionpath(L))
    p.source_sha==String(Tcc._ckpt_sha(windowpath(L))) && binding_ok(p.input_binding) || error("Projected/source SHA or input binding mismatch")
    modes=[m for m in p.modes if Delta(m.energy)<=dmax]
    Q=isempty(modes) ? zeros(length(w.energy),0) : hcat([m.coeff for m in modes]...)
    V=w.vectors*Q;w=nothing;GC.gc()
    norm(V'*V-I)<=1e-6 || error("StageB projected physical vectors not orthonormal")
    sha=bytes2hex(SHA.sha256(join(column_shas(V),"|")))
    (V=V,sha=sha,modes=modes)
end
function ope_stage()
    src=projected(0,5.0);isempty(src.modes) && error("No projected scalar source below Delta5")
    rows=Any[]
    for l in 0:kk_lmax
        tgt=projected(l,6.6)
        isempty(tgt.modes) && continue
        for ins in (:gamma2,:tensorG,:singlet)
            terms=ins==:tensorG ? Tcc.with_obs_r2(()->tensor_parts(N,l),1.0) : ope3_terms(N,ins,l;cache)
            id=(tag="stageB_fullQ",N=N,g=g,sector=sector,source_sha=src.sha,target_sha=tgt.sha,input_binding=binding,
                raw_dmax=raw_dmax,normalization_sha=Tcc.file_digest(joinpath(o3dir,"ope3.toml")),script_sha=Tcc.file_digest(@__FILE__),version=LEAN_VERSION)
            A=Tcc._ope3_edge(out,"$(sector)_$(ins)_L$l",lib,ss,cs[0],cs[l],terms,2l,src,collect(eachindex(src.modes)),tgt,id;workers=act,image_bytes)
            for (i,x) in enumerate(src.modes),(j,z) in enumerate(tgt.modes)
                me1=A.overlaps[1][j,i];me2=length(A.overlaps)>1 ? A.overlaps[2][j,i] : 0.0
                pf=ins==:singlet ? (1+x.P*z.P)/2 : 1.0
                push!(rows,(N,sector,String(ins),l,x.label,x.c2,Delta(x.energy),x.K2,x.sigmaE,x.P,z.label,z.c2,Delta(z.energy),z.K2,z.sigmaE,z.P,me1,me2,pf,src.sha,tgt.sha,"exact_local_fullQ_no_cross_sector_identity_claim"))
            end
            println("STAGEB_OPE N=$N sector=$sector L=$l insertion=$ins sources=$(length(src.modes)) targets=$(length(tgt.modes))");flush(stdout)
        end
        tgt=nothing;GC.gc()
    end
    rows
end
rows=ope_stage()
memlog("ope_done")
Tcc._csv(joinpath(out,"xy_blocks_raw.csv"),["N","sector","insertion","rank","X_label","X_C2","X_Delta","X_K2","X_sigmaE","X_P","Z_label","Z_C2","Z_Delta","Z_K2","Z_sigmaE","Z_P","me_1","me_2","S_even_projection_factor","source_projected_sha","target_projected_sha","identity_status"],rows)
Tcc._csv(joinpath(out,"projected_catalog.csv"),["N","sector","L","label","C2","P","Delta","sigmaE","K2","source_sha","coverage"],catalog)
Tcc._csv(joinpath(out,"kk_coverage.csv"),["sector","L","C2","pseg","status","source_count","excluded_count","missing_L"],coverage)
Tcc._csv(joinpath(out,"prelim_truncated_sources.csv"),["N","sector","L","raw_index","energy","Delta","C2","pseg","limit_E","limit_Delta","short_targets"],truncated_rows)
prelim=!isempty(prelim_partial)
status=prelim ? "preliminary_partial_top_window_truncated_KK_sources" :
    isempty(truncated_rows) ? "complete_exact_local_candidate_components" : "truncated_KK_sources"
man=Dict{String,Any}("N"=>N,"g"=>g,"sector"=>sector,"source_run"=>run,"ope3_source"=>o3dir,
        "raw_basis_Delta_max"=>raw_dmax,"projected_source_Delta_max"=>5.0,"projected_target_Delta_max"=>6.6,
        "spin_max"=>kk_lmax,"KK_target_spin_max"=>raw_lmax,"variant"=>LEAN_VERSION,
        "projected_L_status"=>"KK sources and OPE targets L0..$(kk_lmax); raw L$(raw_lmax) is a KK target only",
        "max_nev"=>cap,"calibration_coefficients"=>fit.coefficients,
        "alpha"=>fit.alpha,"E0"=>fit.E0,"basis_sha"=>bsha,"rows"=>length(rows),"status"=>status,
        "identity_limit"=>"No automatic nearest-energy join to existing integer candidates or previous raw half states",
        "truncated_KK_sources"=>length(truncated_rows),
        "window_frontier"=>Dict("L$L"=>wmeta[L].frontier for L in 0:raw_lmax),
        "window_frontier_Delta"=>Dict("L$L"=>Delta(wmeta[L].frontier) for L in 0:raw_lmax))
if prelim
    m=wmeta[prelim_L]
    man["prelim"]=Dict("partial_window_L"=>prelim_L,"partial_path"=>prelim_partial,"partial_sha"=>m.sha,"partial_k"=>m.k,
        "partial_states"=>length(m.energy),"partial_frontier"=>m.frontier,"partial_frontier_Delta"=>Delta(m.frontier),
        "need"=>need,"need_Delta"=>Delta(need),
        "limits"=>"partial window: no PH labels (raw_spectrum P=0), no complement certificate unless prelim_complement_L$(prelim_L).toml passes; KK sources above the guard are removed (prelim_truncated_sources.csv); projected modes and OPE rows above the source limit are absent",
        "complement_check"=>prelim_complement ? "see prelim_complement_L$(prelim_L).toml" : "not run")
end
open(io->TOML.print(io,man),joinpath(out,"stageB_manifest.toml"),"w")
memlog("done")
println("STAGEB_DONE N=$N sector=$sector rows=$(length(rows)) status=$status truncated_sources=$(length(truncated_rows))");flush(stdout)

# prelim81: complement check of the partial window, after every output is written
if prelim && prelim_complement
    L=prelim_L;D=cs[L].dim;rows=nothing;catalog=nothing;coverage=nothing;GC.gc()
    H=absorb!(set_g!(Tcc.BuildCompOperator(cs[L],tpl.template,sH;num_th=act),tpl,g),fH)
    p=load_prelim_partial()
    memlog("prelim_complement_L$L")
    t0=time();chk=lean_complement_check(H,D,p.energy,p.vectors,act,tol,99000+L)
    ok=chk.min_margin>guard
    open(joinpath(out,"prelim_complement_L$L.toml"),"w") do io
        TOML.print(io,Dict("L"=>L,"states"=>length(p.energy),"top_energy"=>last(p.energy),"top_Delta"=>Delta(last(p.energy)),
            "frontier"=>p.frontier,"min_margin"=>chk.min_margin,"guard"=>guard,"status"=>ok ? "pass" : "FAIL",
            "seed"=>99000+L,"seconds"=>time()-t0,"partial_sha"=>wmeta[L].sha))
    end
    println(ok ? "PRELIM_COMPLEMENT_PASS" : "PRELIM_COMPLEMENT_FAIL"," L=$L margin=$(chk.min_margin) guard=$guard seconds=$(round(time()-t0))");flush(stdout)
    ok || exit(7)
end
