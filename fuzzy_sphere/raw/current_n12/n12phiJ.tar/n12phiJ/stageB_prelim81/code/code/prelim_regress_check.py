"""prelim81 gate (stdlib only): a run on a partial top-L window (PRE) against the complete v2.1 run on
the same lower windows (REF).
  python3 prelim_regress_check.py REF_DIR PRE_DIR [J_ONLY]
Checks
  1. phi -> J control (raw_current_control.toml) identical;
  2. phi -> J full-Q row (gamma2, rank 1, Z C2=3, Delta=2): |me_1| relative difference <= 1e-10, Z_K2 equal;
  3. every rank-0 row (targets at L0, whose KK uses complete windows only) equal up to sign, rel 1e-8;
  4. L1 C2=3 P=+1 modes of REF with Delta < 4.7: a PRE mode within |dDelta| < 1e-4 whose phi gamma2 |me_1|
     differs by <= 1e-3 relatively (the N8-11 offline truncation test gives <= 1e-4);
  5. projected_catalog rows at L0 identical (label, P, Delta to 1e-10);
  6. PRE removed sources only at or above its recorded limit, and its manifest says preliminary;
  7. PRE complement check of the partial window passed (when the file exists).
J_ONLY (N12 production use, no REF): prints the phi -> J row and the L1 C2=3 rows of PRE only."""
import csv, math, pathlib, sys

def toml_flat(path):
    """Minimal reader for the flat TOML written by TOML.print (Python 3.9 on the cluster has no tomllib):
    'key = value' lines, '[a.b]' headers give dotted keys; strings, numbers and booleans only."""
    out, sec = {}, ""
    for line in pathlib.Path(path).read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith("[") and s.endswith("]"):
            sec = s.strip("[]").strip() + "."; continue
        if "=" not in s:
            continue
        k, v = (x.strip() for x in s.split("=", 1))
        if v.startswith('"'):
            v = v[1:v.rindex('"')]
        elif v in ("true", "false"):
            v = v == "true"
        else:
            for conv in (int, float):
                try:
                    v = conv(v); break
                except ValueError:
                    pass
        out[sec + k.strip('"')] = v
    return out

def rows(d, name):
    with (pathlib.Path(d) / name).open(newline="", encoding="utf-8-sig") as io:
        return list(csv.DictReader(io))

def f(r, k):
    return float(r[k])

def phi_label(xy):
    c = [r for r in xy if int(f(r, "X_C2")) == 2]
    return min(c, key=lambda r: f(r, "X_Delta"))["X_label"]

def l1_c3(xy, phi):
    return sorted([r for r in xy if r["insertion"] == "gamma2" and r["rank"] == "1" and r["X_label"] == phi
                   and int(f(r, "Z_C2")) == 3 and int(f(r, "Z_P")) == 1], key=lambda r: f(r, "Z_Delta"))

def show(tag, xy):
    phi = phi_label(xy)
    for r in l1_c3(xy, phi):
        print(f"PRELIM_ROW {tag} X={phi} Z={r['Z_label']} Z_Delta={f(r,'Z_Delta'):.9f} Z_K2={f(r,'Z_K2'):.3e} "
              f"Z_sigmaE={f(r,'Z_sigmaE'):.3e} me_1={f(r,'me_1'):+.15e}")

if len(sys.argv) >= 3 and sys.argv[2] == "J_ONLY":
    show("PRE", rows(sys.argv[1], "xy_blocks_raw.csv"))
    sys.exit(0)

ref, pre = sys.argv[1], sys.argv[2]
fails = []
def check(name, ok, note=""):
    print(f"PRELIM_CHECK {name} {'pass' if ok else 'FAIL'} {note}".rstrip())
    ok or fails.append(name)

a = toml_flat(pathlib.Path(ref) / "raw_current_control.toml")
b = toml_flat(pathlib.Path(pre) / "raw_current_control.toml")
check("raw_current_control", a["status"] == b["status"] == "pass" and abs(a["new_abs_ME"] - b["new_abs_ME"]) <= 1e-12 * abs(a["new_abs_ME"]),
      f"{a['new_abs_ME']} vs {b['new_abs_ME']}")

xa, xb = rows(ref, "xy_blocks_raw.csv"), rows(pre, "xy_blocks_raw.csv")
phi = phi_label(xa)
check("phi_label", phi == phi_label(xb), phi)
ja = [r for r in l1_c3(xa, phi) if abs(f(r, "Z_Delta") - 2) < 1e-6]
jb = [r for r in l1_c3(xb, phi) if abs(f(r, "Z_Delta") - 2) < 1e-6]
ok = len(ja) == len(jb) == 1
if ok:
    ma, mb = abs(f(ja[0], "me_1")), abs(f(jb[0], "me_1"))
    rel = abs(ma - mb) / ma
    ok = rel <= 1e-10 and f(ja[0], "Z_K2") == f(jb[0], "Z_K2")
    check("phi_phi_J", ok, f"|me| {ma:.15e} vs {mb:.15e} rel {rel:.2e} K2 {f(ja[0],'Z_K2')} / {f(jb[0],'Z_K2')}")
else:
    check("phi_phi_J", False, f"J rows ref {len(ja)} pre {len(jb)}")

key = lambda r: (r["insertion"], r["X_label"], r["Z_label"])
r0a = {key(r): r for r in xa if r["rank"] == "0"}; r0b = {key(r): r for r in xb if r["rank"] == "0"}
scale = max([abs(f(r, c)) for r in r0a.values() for c in ("me_1", "me_2")] + [1.0])
bad = [k for k in r0a if k not in r0b or any(abs(abs(f(r0a[k], c)) - abs(f(r0b[k], c))) > 1e-8 * abs(f(r0a[k], c)) + 1e-12 * scale
                                         for c in ("me_1", "me_2"))]
check("rank0_rows", len(r0a) == len(r0b) and not bad, f"{len(r0a)} vs {len(r0b)} rows, {len(bad)} differ")

worst = 0.0; miss = []
for r in l1_c3(xa, phi):
    D = f(r, "Z_Delta")
    if D >= 4.7:
        continue
    c = [s for s in l1_c3(xb, phi) if abs(f(s, "Z_Delta") - D) < 1e-4]
    if len(c) != 1:
        miss.append(D); continue
    m0, m1 = abs(f(r, "me_1")), abs(f(c[0], "me_1"))
    worst = max(worst, abs(m0 - m1) / max(m0, 1e-300))
    print(f"PRELIM_L1C3 Delta_ref={D:.9f} Delta_pre={f(c[0],'Z_Delta'):.9f} |me| {m0:.9e} vs {m1:.9e}")
check("L1_C2_3_low_modes", not miss and worst <= 1e-3, f"worst rel |me| diff {worst:.2e}, unmatched {miss}")

ca = [r for r in rows(ref, "projected_catalog.csv") if r["L"] == "0"]
cb = [r for r in rows(pre, "projected_catalog.csv") if r["L"] == "0"]
check("catalog_L0", len(ca) == len(cb) and all(x["label"] == y["label"] and x["P"] == y["P"] and abs(f(x, "Delta") - f(y, "Delta")) <= 1e-10
                                               for x, y in zip(ca, cb)), f"{len(ca)} vs {len(cb)} modes")

tr = rows(pre, "prelim_truncated_sources.csv")
man = toml_flat(pathlib.Path(pre) / "stageB_manifest.toml")
check("truncation", man["status"].startswith("preliminary") and all(f(r, "energy") >= f(r, "limit_E") for r in tr) and len(tr) > 0,
      f"{len(tr)} removed sources, status {man['status']}")
cp = pathlib.Path(pre) / f"prelim_complement_L{man['prelim.partial_window_L']}.toml"
if cp.exists():
    c = toml_flat(cp)
    check("partial_complement", c["status"] == "pass", f"margin {c['min_margin']} guard {c['guard']}")
show("REF", xa); show("PRE", xb)
print("PRELIM81_REGRESS_N8_PASS" if not fails else f"PRELIM81_REGRESS_N8_FAIL {fails}")
sys.exit(1 if fails else 0)
